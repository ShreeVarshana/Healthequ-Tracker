import React from 'react'

const LoadingSpinner2 = () => {
  return (
    <div className="spinner2">
    <div className="double-bounce1"></div>
    <div className="double-bounce2"></div>
  </div>
  )
}

export default LoadingSpinner2
